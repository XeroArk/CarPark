package com.example.carpark.appuser;

public enum AuthenticationProvider {
    LOCAL,
    GOOGLE
}
