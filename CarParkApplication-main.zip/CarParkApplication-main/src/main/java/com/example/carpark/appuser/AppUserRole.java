package com.example.carpark.appuser;

public enum AppUserRole {
    ROLE_USER,
    ROLE_ADMIN
}
