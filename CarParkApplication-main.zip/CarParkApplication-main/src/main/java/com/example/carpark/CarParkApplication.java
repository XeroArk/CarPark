package com.example.carpark;

import com.example.carpark.appuser.AppUserRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarParkApplication {


    public static void main(String[] args) {
        SpringApplication.run(CarParkApplication.class, args);

    }


}
