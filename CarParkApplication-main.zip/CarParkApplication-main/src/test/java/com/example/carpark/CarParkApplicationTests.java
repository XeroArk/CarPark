package com.example.carpark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarParkApplicationTests {

    @Test
    void contextLoads() {
    }

}
